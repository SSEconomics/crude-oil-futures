// -----------------------------	
// Stephen Snudden Aug 2023
// Replication files for:
// Ellwanger, R. and S. Snudden, 2023. “Futures Prices are Useful Predictors of the Spot Price of Crude Oil” The Energy Journal, vol. 44(4): 65-82.
// -----------------------------	

// Sample 1992.1-2021.1, evaluate 2021.5

//****************
// DATA
//****************
// Compile Futures Data
//*
cd "Data_Historical\CompileFutures"
do "brent_futures.do"  
do "wti_futures.do" 
cd "..\.."
*/

//****************
// Nowcast CPI
//*
cd "Forecasts_M\Nowcasts"
do "Nowcasts.do" 
cd "..\.."
*/

//****************
// FUTURES FORECASTS
//****************

// Imputs: commodity starty startm endy endm, NominalEoM=1(real monthly average=0) table# Model(EoM_ADJ=3,alpha=8, beta=9, alpha&beta=10) realtime(1=yes, 0=no)
// EXAMPLE: 
// do "FUTURES.do" wti 1991 12 2020 12 0 1 3 1
// WTI crude oil, 1991m12-2020m12 (evaluate from 1992m1-2021m1), forecasts of real monthly average, tab 1, use adjusted end of month futures, use real-time forecast methods 

//****************
// Non-parametric real-time forecasts of real monthly average prices
// Note the sample dates are adjusted by t-1 since forecast is for t+1
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 2001.1-2021.1
do "FUTURES.do" wti   2000 12 2020 12 0 1 3 1
do "FUTURES.do" brent 2000 12 2020 12 0 1 3 1
do "FUTURES.do" rac   2000 12 2020 12 0 1 3 1
cd "..\.."
*/
//****************
// Parametric forecasts real-time forecasts of real monthly average prices
// Note the sample dates are adjusted by t-1 since forecast is for t+1
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 2001.1-2021.1
do "FUTURES.do" wti 2000 12 2020 12 0 2 8 1
do "FUTURES.do" wti 2000 12 2020 12 0 2 9 1
do "FUTURES.do" wti 2000 12 2020 12 0 2 10 1
cd "..\.."
*/

