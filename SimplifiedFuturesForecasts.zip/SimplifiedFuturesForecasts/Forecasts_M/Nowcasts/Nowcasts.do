// -----------------------------	
// Stephen Snudden Aug 2023
// -----------------------------	

//*********
//Intro formalities

clear all
set more off

capture drop _all
capture log using log.smcl, replace
set more off
timer on 1

local imputfile="..\..\Data_RealTime\MASTERFILE_RealTime_Data.xlsx"
local outputfile="BES_Real_Time_EIA_Data_nowcasted.xlsx"


*********
//Data nowcasted with average growth rates
*********

foreach nn in "1973m1" "1986m7" "1990m1"  { 	
	clear all 
	// Load data
	import excel using "`imputfile'", sheet("US CPI Fraser") firstrow
	gen time=tm(1973m1)+ _n-1
	format time %tm
	tsset time
	gen t=_n   
	local mm=1 // month from 1-12
	local aa=1991 // year from start of the real time data 
    local name="ei"
	local name2="ei"
	// Loop over years
	display "Nowcasting US CPI Fraser" 
	foreach a of numlist 1991(1)2021 {
	local y=string(mod(`a', 100),"%02.0f")
	// Loop over months
		foreach m in jan feb mar apr may jun jul aug sep oct nov dec {
		  qui gen dl`name'_`m'_`y' = `name'_`m'_`y'/l.`name'_`m'_`y'-1 if time>=tm(`nn')
		  qui sum dl`name'_`m'_`y'
		  gen ave_dl`name'=r(mean)
		  qui sum `name'_`m'_`y'
		  local obs = r(N)
		  qui replace `name'_`m'_`y' = (1+ave_dl`name')*l.`name'_`m'_`y' if time<=tm(`a'm`mm') & t>`obs'
		  qui rename `name'_`m'_`y' `name2'_`mm'_`aa'
		  drop dl`name'_`m'_`y' ave_dl`name'
		  if `mm'<12 { 
			local mm=`mm'+1 
		  } 
		  else if `mm'==12 { 
		  	local mm=1 
		  	local aa=`aa'+1 
		  }
	  }
	}
	drop t time
	export excel using `outputfile', sheet("CPInowcast`nn'", replace)  first(var) keepcellfmt
}


*********
//Nowcasted using change in WTI
*********
 
// Load Current Data
clear all
import delimited "..\..\Data_Historical\MasterFile_CDataM.csv"
*gen time = date(date,"YMD")
gen time=tm(1973m1)+ _n-1
format time %tm
tsset time
keep time wti wti_lastday
save "DataM.dta", replace

foreach sheet in "nominal RAC" { 	
		clear all 
		// Load data
		import excel using `imputfile', sheet(`sheet') firstrow
		gen time=tm(1973m1)+ _n-1
		format time %tm
		merge 1:m time using "DataM.dta", nogenerate
		tsset time
		gen t=_n   
		local mm=1 // month from 1-12
		local aa=1991 // year from start of the real time data 
		local name="mer"	
		qui gen dlwti = wti/l.wti-1
		// Loop over years
		display "Nowcasting `sheet'" 
		foreach a of numlist 1991(1)2021 {
		local y=string(mod(`a', 100),"%02.0f")
			// Loop over months
			foreach m in jan feb mar apr may jun jul aug sep oct nov dec {
			qui sum mer_`m'_`y'
			local obs = r(N)
			*display `obs'
			qui replace mer_`m'_`y' = (1+dlwti)*l.mer_`m'_`y' if time<=tm(`a'm`mm') & t>`obs'
			qui rename `name'_`m'_`y' `name'_`mm'_`aa'
			if `mm'<12 { 
				local mm=`mm'+1 
			} 
			else if `mm'==12 { 
				local mm=1 
				local aa=`aa'+1 
			}
		  } // Year
		}
		drop t time dlwti wti wti_lastday
		export excel using `outputfile', sheet("RAC", replace) first(var) keepcellfmt
} // Data tab

//---------------------------------------------------------------------------------------------------------
//End of file
//---------------------------------------------------------------------------------------------------------

capture log close 
timer off 1
timer list 1
