
args cpi
clear all

//*********
// Load Data
//*********

// Load Oil Data
clear all
insheet using "..\..\Data_Historical\MasterFile_CDataM.csv"
gen time=tm(1973m1)+ _n-1
format time %tm
tsset time
keep time wti wti_lastday brent brent_lastday
save "Data.dta", replace
// Load Oil Data
clear all
import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(RAC) firstrow
gen time=tm(1973m1)+ _n-1
format time %tm
merge 1:m time using "Data.dta", nogenerate
save "Data.dta", replace
clear all 
//CPI
clear all 
import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(CPInowcast1986m7) firstrow
gen time=tm(1973m1)+ _n-1
format time %tm
merge 1:m time using "Data.dta", nogenerate
save "Data.dta", replace
clear all 
//CPI
clear all 
sysuse "FUT.dta"
format time %tm
merge 1:m time using "Data.dta", nogenerate
tsset time
gen t=_n   

