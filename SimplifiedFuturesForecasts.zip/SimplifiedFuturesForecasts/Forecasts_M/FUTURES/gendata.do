
//*********
// Load Data
//*********

args var nom mod rt
 
// Load Oil Data
clear all
insheet using "..\..\Data_Historical\MasterFile_CDataM.csv"
gen time=tm(1973m1)+ _n-1
format time %tm
tsset time 

if `mod'==8 | `mod'==9 | `mod'==10 {
  keep time wti wti_lastday brent brent_lastday wti_1mfut_lastday wti_3mfut_lastday wti_6mfut_lastday wti_9mfut_lastday wti_12mfut_lastday wti_24mfut_lastday wti_36mfut_lastday
}
else  {
  keep time wti wti_lastday brent brent_lastday
}

tsappend, add(70)
save "FUT.dta", replace

if "`var'"=="rac" {
  local imputfile="..\..\Data_Historical\futuresdatawti.xlsx"
}
else  {
  local imputfile="..\..\Data_Historical\futuresdata`var'.xlsx"
}
  
local cc=1
// Create Forecast Curve Nominal
foreach sheet in "Last_day_month" "Monthly_Average" "Last_day_monthBC12" { 	
    clear all
	import excel using "`imputfile'", sheet(`sheet') firstrow
    if "`var'"=="brent" {
		gen time=tm(1988m6)+ _n-1
	}
	else  {
		gen time=tm(1986m7)+ _n-1
	}
	drop month year mydate
	format time %tm
	sort time
	merge m:1 time using "FUT.dta", nogenerate
	tsset time
    local tt=217
    foreach a of numlist 1991(1)2020 {
		foreach m of numlist 1(1)12 {
			qui gen f_fut`cc'_`m'_`a' = . 
				foreach h of numlist 1(1)72 { 
					local tth=`tt'+`h'
					qui replace f_fut`cc'_`m'_`a' = L`h'.CL`h' in `tth'
				}
			local tt=`tt'+1
		}
	}
	foreach h of numlist 1(1)72 { 
		drop CL`h'
	}
    save "FUT.dta", replace
	local cc=`cc'+1 
} //sheet 

// Create Real Price Forecast Spread Models
clear all 
import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(CPInowcast1986m7) firstrow
gen time=tm(1973m1)+ _n-1
format time %tm
merge 1:m time using "FUT.dta", nogenerate
foreach a of numlist 1991(1)2021 {
	foreach m of numlist 1(1)12 {
		qui replace ei_`m'_`a'=ei_`m'_`a'/100
	}
}
save "FUT.dta", replace
tsset time

// Load RAC Data
if "`var'"=="rac" {
  clear all
  import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(RAC) firstrow
  gen time=tm(1973m1)+ _n-1
  format time %tm
  merge 1:m time using "FUT.dta", nogenerate
  save "FUT.dta", replace
  tsset time
}

// Real Futures
local tt=217
foreach a of numlist 1991(1)2020 {
    foreach m of numlist 1(1)12 {
		// Run out inflation rate
		if `rt'==1 {
		  qui gen pie_`m'_`a'=(ei_`m'_`a'/l.ei_`m'_`a'-1) if time>=tm(1986m7)
		  qui sum pie_`m'_`a'
		  local mei=r(mean)
		  qui replace ei_`m'_`a'=(1+`mei')*L.ei_`m'_`a' if _n>`tt'
		  drop pie_`m'_`a'
		}
		else if `rt'==0 {
		  qui replace ei_`m'_`a'=ei_5_2021
		}
		// realtime real measures
		if `nom'==0 & "`var'"=="rac" & `rt'==1 { 
		  qui gen `var'_lastday=wti_lastday
		  qui gen rpoil_ld=(wti_lastday/wti)*mer_`m'_`a'/ei_`m'_`a'
		  qui gen rpoil= mer_`m'_`a'/ei_`m'_`a'
		  qui gen pieh_`m'_`a'=ei_`m'_`a'/ei_`m'_`a'[`tt']
          } 
		else if `nom'==0 & `rt'==1 { 
		  qui gen rpoil_ld=`var'_lastday/ei_`m'_`a'
		  qui gen rpoil= `var'/ei_`m'_`a'
		  qui gen pieh_`m'_`a'=ei_`m'_`a'/ei_`m'_`a'[`tt']
        }   
		else if `nom'==0 & "`var'"=="rac" & `rt'==0 { 
		  qui gen `var'_lastday=wti_lastday
		  qui gen rpoil_ld=(wti_lastday/wti)*mer_5_2021/ei_`m'_`a'
		  qui gen rpoil= mer_5_2021/ei_`m'_`a'
		  qui gen pieh_`m'_`a'=ei_`m'_`a'/ei_`m'_`a'[`tt']
          } 
		else if `nom'==0 & `rt'==0 { 
		  qui gen rpoil_ld=`var'_lastday/ei_`m'_`a'
		  qui gen rpoil= `var'/ei_`m'_`a'
		  qui gen pieh_`m'_`a'=ei_`m'_`a'/ei_`m'_`a'[`tt']
        }   
        else if `nom'==1  { 
		  qui gen rpoil_ld=`var'_lastday
		  qui gen rpoil= `var'
		  qui gen pieh_`m'_`a'=1
        }
		// Parametric futures spread model
		if `mod'==8 | `mod'==9 | `mod'==10 {
		  qui gen f_fut8_`m'_`a' =.
		  qui gen f_fut9_`m'_`a' =.
		  qui gen f_fut10_`m'_`a' =.
		  foreach h of numlist 1 3 6 9 12 24 36 {  
			local th=`tt'+`h'
		    if `h'<=12 | `a'>=2011 {
			  qui gen y_beta=(rpoil/l`h'.rpoil_ld-1)
		      qui gen x_beta=ln(l`h'.`var'_`h'mfut_lastday)-ln(l`h'.`var'_lastday)-ln(l`h'.pieh_`m'_`a')
		   	  qui reg y_beta x_beta if _n<=`tt', noconstant 
		      scalar beta =_b[x_beta]
		      constraint 1 x_beta = 1
		      qui cnsreg y_beta x_beta if _n<=`tt', constraint(1)
		      scalar alpha =_b[_con]
		      qui replace f_fut8_`m'_`a' = rpoil_ld[`tt']*(1+alpha+ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a')) if _n==`th' 
		      qui replace f_fut9_`m'_`a' = rpoil_ld[`tt']*(1+beta*(ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a'))) if _n==`th' 
		      // Intercept and Beta
		      qui reg y_beta x_beta if _n<=`tt'
		      scalar alpha =_b[_con]
		      scalar beta =_b[x_beta]
		      qui replace f_fut10_`m'_`a' = rpoil_ld[`tt']*(1+alpha+beta*(ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a'))) if _n==`th' 
		      drop y_beta x_beta //y_int
			}
			else {
			  qui replace f_fut8_`m'_`a' = rpoil_ld[`tt']*(1+ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a')) if _n==`th' 
		      qui replace f_fut9_`m'_`a' = rpoil_ld[`tt']*(1+ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a')) if _n==`th' 
		      qui replace f_fut10_`m'_`a' = rpoil_ld[`tt']*(1+ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a')) if _n==`th' 
			}
			
		  }
		}
		// Non-parametric futures spread model
		if `mod'==4 {
		  qui replace f_fut3_`m'_`a' = f_fut1_`m'_`a'/ ei_`m'_`a'
		}	
		else {
		  qui replace f_fut3_`m'_`a' = rpoil_ld[`tt']*(1+ln(f_fut3_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a'))
		}
		qui replace f_fut1_`m'_`a' = rpoil_ld[`tt']*(1+ln(f_fut1_`m'_`a')-ln(`var'_lastday[`tt'])-ln(pieh_`m'_`a'))
		qui replace f_fut2_`m'_`a' = rpoil[`tt']*(1+ln(f_fut2_`m'_`a')-ln(`var'[`tt'])-ln(pieh_`m'_`a')) 
		drop rpoil_ld rpoil pieh_`m'_`a' ei_`m'_`a' //meik
		local tt=`tt'+1
		if "`var'"=="rac" {
		   drop `var'_lastday
		}
	}
}

capture drop mer_*
drop ei_*	
drop wti wti_lastday brent brent_lastday
save "FUT.dta", replace



