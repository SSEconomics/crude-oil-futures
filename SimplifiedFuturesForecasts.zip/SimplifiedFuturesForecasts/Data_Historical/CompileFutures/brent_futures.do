
clear all

capture drop _all
capture log close
set more off
log using logfile, replace

//*********
// Load Data
//*********

import excel using "Daily_Brent", sheet("data") firstrow
save "Data.dta", replace

*tostring date, gen(data) // if a string
gen data=date       // if a number
gen month = substr(data,5,2)
gen day = substr(data,7,2)
gen year = substr(data,1,4)
destring month day year, replace
gen time= date(data, "YMD")
format time %td
drop if missing(CL2)
bcal create eia, from(time) replace
gen mydate = bofd("eia", time) 
format mydate %tbeia
assert mydate!=. if time!=.
tsset mydate
sort mydate
gen t=_n


//*********
// Clean Data
//*********

// Extend futures data forward if missing
foreach i of numlist 2(1)97 { //
	local mi=`i'-1 
	*qui replace CL`i'=(1+0.045/12)*CL`mi' if missing(CL`i') // grow missing nominal using CPI at that time. only effects 1986/1995 forecasts at 24/36 horizon
	qui replace CL`i'=CL`mi' if missing(CL`i')
}

drop data
save "Data.dta", replace

//*********
// Save the cases
//*********

//*********
// Last observed monthly date
clear all
sysuse "Data.dta"
gen dm=f.month-month
drop if dm==0
drop if t>8259
drop t time day date dm
export excel using "..\futuresdatabrent.xlsx", sheet("Last_day_month", replace) first(var) keepcellfmt

//*********
// Monthly average

clear all 
sysuse "Data.dta"
gen dm=f.month-month
sort year month
foreach i of numlist 1(1)72 { // 
	by year month: egen ave`i'=mean(CL`i')
	qui drop CL`i'
	qui rename ave`i' CL`i'
}
drop if dm==0
drop if t>8259
drop t time day date dm
export excel using "..\futuresdatabrent.xlsx", sheet("Monthly_Average", replace) first(var) keepcellfmt


//*********
// Adjusted timing and impute one-month-ahead, growth rate of first 12 months 
 
clear all
sysuse "Data.dta"
// Growth rate
foreach i of numlist 11(-1)1 { // 
	local ii=`i'+1
	qui gen grCL`ii' = CL`i'/CL`ii'-1
}
// Rename
foreach i of numlist 97(-1)1 { // 
	local ii=`i'+1
	qui rename CL`i' CL`ii'
}
egen avegr =  rmean(grCL*) 
gen CL1=CL2*(avegr+1)
drop grCL* avegr
gen dm=f.month-month
drop if dm==0
drop t time day date dm 
export excel using "..\futuresdatabrent.xlsx", sheet("Last_day_monthBC12", replace) first(var) keepcellfmt


