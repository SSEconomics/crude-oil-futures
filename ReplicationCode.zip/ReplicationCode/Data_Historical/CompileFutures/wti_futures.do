
clear all

capture drop _all
capture log close
set more off
log using logfile, replace

//*********
// Load Data
//*********

import excel using "Daily_WTI", sheet("daily wti") firstrow
drop mm yyyy mmm dd
save "Data.dta", replace
clear all
import excel using "Daily_WTI", sheet("date") firstrow
merge 1:m oldate using "Data.dta", nogenerate
drop oldate

*tostring date, gen(data)
gen data=date
gen month = substr(data,5,2)
gen day = substr(data,7,2)
gen year = substr(data,1,4)
destring month day year, replace
gen time= date(data, "YMD")
format time %td
drop if missing(CL2)
bcal create eia, from(time) replace
gen mydate = bofd("eia", time) 
format mydate %tbeia
assert mydate!=. if time!=.
tsset mydate
sort mydate
gen t=_n
drop data
save "Data.dta", replace

drop if t<373 // drop before July 1 1986
replace t=_n

//*********
// Clean Data
//*********

// fix contract date bugs
foreach i of numlist 1(1)24 { // 
	qui replace CLD`i'=L.CLD`i' if t==493
	qui replace CLD`i'=L.CLD`i' if t==914
	foreach tt of numlist 1760(-1)1754 { // 
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}	
	qui replace CLD`i'=L.CLD`i' if t==2172
	qui replace CLD`i'=L.CLD`i' if t==2382
	qui replace CLD`i'=L.CLD`i' if t==2664
	qui replace CLD`i'=L.CLD`i' if t==2683
	
	qui replace CLD`i'=L.CLD`i' if t==2694
	qui replace CLD`i'=L.CLD`i' if t==2698
	qui replace CLD`i'=L.CLD`i' if t==2705
	qui replace CLD`i'=L.CLD`i' if t==2720
	qui replace CLD`i'=L.CLD`i' if t==2874
	
	qui replace CLD`i'=L.CLD`i' if t==2931
	
	qui replace CLD`i'=L.CLD`i' if t==3202
	qui replace CLD`i'=L.CLD`i' if t==3295
	qui replace CLD`i'=L.CLD`i' if t==3346

	qui replace CLD`i'=L.CLD`i' if t==3532
	*foreach tt of numlist 3595(-1)3591 {  
	*	qui replace CLD`i'=F.CLD`i' if t==`tt'
	*}
	qui replace CLD`i'=L.CLD`i' if t==3665
	qui replace CLD`i'=L.CLD`i' if t==3706
	qui replace CLD`i'=L.CLD`i' if t==3809
	
	foreach tt of numlist 3826(-1)3822 {  
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}		
	
	qui replace CLD`i'=L.CLD`i' if t==3844	
	qui replace CLD`i'=L.CLD`i' if t==3866
    
	qui replace CLD`i'=L.CLD`i' if t==3985	
	qui replace CLD`i'=L.CLD`i' if t==3986
	
	foreach tt of numlist 4209(-1)4208 {  
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}	
	qui replace CLD`i'=L.CLD`i' if t==4321
	qui replace CLD`i'=L.CLD`i' if t==4346
	
	qui replace CLD`i'=L.CLD`i' if t==4735
	qui replace CLD`i'=L.CLD`i' if t==4736
	
	qui replace CLD`i'=L.CLD`i' if t==4990
	qui replace CLD`i'=L.CLD`i' if t==4991
	
	qui replace CLD`i'=L.CLD`i' if t==5010
	qui replace CLD`i'=L.CLD`i' if t==5011
	qui replace CLD`i'=L.CLD`i' if t==5012
	qui replace CLD`i'=L.CLD`i' if t==5075
	
	foreach tt of numlist 5882(-1)5873 { 
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}
	foreach tt of numlist 5923(-1)5913 { 		
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}
	foreach tt of numlist 5956(-1)5953 { 		
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}
	foreach tt of numlist 5976(-1)5973 { 		
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}
	foreach tt of numlist 5997(-1)5995 { 		
		qui replace CLD`i'=F.CLD`i' if t==`tt'
	}
	qui replace CLD`i'=L.CLD`i' if t==6190
	*qui replace CLD`i'=L.CLD`i' if t==6294
	
	*qui replace CLD`i'=L.CLD`i' if t==6370
	*qui replace CLD`i'=L.CLD`i' if t==6371
	
	qui replace CLD`i'=L.CLD`i' if t==6601
	qui replace CLD`i'=L.CLD`i' if t==6602
	
	 // qui replace CLD`i'=L.CLD`i' if t==6625
}

// Fill in missing trading data
replace CLD1=L.CLD1 if missing(CLD1)
replace CL1=L.CL1 if missing(CL1)

foreach i of numlist 2(1)72 { //
	local mi=`i'-1 
	*qui replace CL`i'=(1+0.045/12)*CL`mi' if missing(CL`i') // grow missing nominal using CPI at that time. only effects 1986/1995 forecasts at 24/36 horizon
	qui replace CL`i'=CL`mi' if missing(CL`i')
}

//If no issues save
save "Data.dta", replace

//*********
// Save the cases
//*********

//*********
//Last observed trading date
// Indicator for last contract date
foreach i of numlist 1(1)24 { // 
	qui gen id`i'=F.CLD`i'-CLD`i'
	qui replace id`i'=1 if id`i'!=0 & !missing(CLD`i')
}
/*
// Double check for bugs in the contract dates
foreach yy of numlist 1987(1)2019 { // 
	foreach mm of numlist 1(1)12 { // 
		qui sum id2 if month==`mm' & year==`yy' & id2!=0
		local ave=r(mean)
		if `ave' !=1{
			display " `yy' `mm' "
		} // ave
	} //mm
} //yy
*/
drop if id2!=1
drop if t>8683
drop t time day date
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i' id`i'
}
//Save
export excel using "..\futuresdatawti.xlsx", sheet("Last_day_contract", replace) first(var) keepcellfmt

//*********
// Last observed monthly date
clear all
sysuse "Data.dta"
gen dm=f.month-month
drop if dm==0
drop if t>8690
drop t time day date dm
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i'
}
export excel using "..\futuresdatawti.xlsx", sheet("Last_day_month", replace) first(var) keepcellfmt

//*********
// Contract month average

clear all 
sysuse "Data.dta"
gen id=F.CLD2-CLD2
qui replace id=1 if id!=0 
gen csum=0
replace csum= l.csum+l.id if t>1
sort csum
foreach i of numlist 1(1)72 { // 
	by csum: egen ave`i'=mean(CL`i')
	qui drop CL`i'
	qui rename ave`i' CL`i'
}
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i'
}
drop if id==0
drop if t>8690
drop t time day date id csum
export excel using "..\futuresdatawti.xlsx", sheet("Contract_Average", replace) first(var) keepcellfmt

//*********
// Monthly average

clear all 
sysuse "Data.dta"
gen dm=f.month-month
sort year month
foreach i of numlist 1(1)72 { // 
	by year month: egen ave`i'=mean(CL`i')
	qui drop CL`i'
	qui rename ave`i' CL`i'
}
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i'
}
drop if dm==0
drop if t>8690
drop t time day date dm
export excel using "..\futuresdatawti.xlsx", sheet("Monthly_Average", replace) first(var) keepcellfmt

//*********
// Last observed 3 days of month 
clear all
sysuse "Data.dta"
gen dm=f.month-month
gen dmi=dm
replace dmi=1 if F.dmi!=0 | F2.dmi!=0 & dmi==0
drop if dmi==0
sort year month
foreach i of numlist 1(1)72 { // 
	by year month: egen ave`i'=mean(CL`i')
	qui drop CL`i'
	qui rename ave`i' CL`i'
}
drop if dm==0
drop if t>8690
drop t time day date dm dmi
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i'
}
export excel using "..\futuresdatawti.xlsx", sheet("Last_3days_month", replace) first(var) keepcellfmt

//*********
// Adjusted timing and impute one-month-ahead, growth rate of first 12 months 
 
clear all
sysuse "Data.dta"
// Growth rate
foreach i of numlist 11(-1)1 { // 
	local ii=`i'+1
	qui gen grCL`ii' = CL`i'/CL`ii'-1
}
// Rename
foreach i of numlist 72(-1)1 { // 
	local ii=`i'+1
	qui rename CL`i' CL`ii'
}
egen avegr =  rmean(grCL*) 
gen CL1=CL2*(avegr+1)
drop grCL* avegr
gen dm=f.month-month
drop if dm==0
drop t time day date dm 
foreach i of numlist 1(1)24 { // 
	qui drop CLD`i'
}
export excel using "..\futuresdatawti.xlsx", sheet("Last_day_monthBC12", replace) first(var) keepcellfmt





