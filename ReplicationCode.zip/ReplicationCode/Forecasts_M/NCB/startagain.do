args cpi

clear all

capture drop _all
capture log close
set more off
log using logfile, replace

//*********
// Load Data
//*********

// Load Oil Data
clear all
insheet using "..\..\Data_Historical\MasterFile_CDataM.csv"
gen time=tm(1973m1)+ _n-1
format time %tm
tsset time
keep time wti wti_lastday brent brent_lastday
save "Data.dta", replace
//CPI
clear all 
if `cpi'==73 {
  import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(CPInowcast1973m1) firstrow
}
else if `cpi'==86 {
  import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(CPInowcast1986m7) firstrow
}
else if `cpi'==90 {
  import excel using "..\Nowcasts\BES_Real_Time_EIA_Data_nowcasted.xlsx", sheet(CPInowcast1990m1) firstrow
}
gen time=tm(1973m1)+ _n-1
format time %tm
merge 1:m time using "Data.dta", nogenerate
save "Data.dta", replace
tsset time
gen t=_n   

