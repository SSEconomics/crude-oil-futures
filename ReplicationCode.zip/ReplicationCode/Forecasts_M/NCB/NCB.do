// -----------------------------	
// Stephen Snudden Aug 2023
// -----------------------------	

//*********
//Intro formalities

args var aa mm endy endm table cpi

clear all

//*********
// Load Data
//*********
 
*quietly {

  do "Startagain.do" `cpi'
  tsappend, add(70)
  set more off

  capture log close
  log using logfile, replace

  local p=1
  local name="EoM NC"
  qui gen r`var'= `var'/ei_5_2021*100

  display "FORECAST CRITERION FOR END-OF-PERIOD PRICES FOR `var'" 

  // Set dates. 
  local mm=`mm' // month to start
  local aa=`aa' // year to start
  local startdate = "`aa'm`mm'"
  local enddate = "`endy'm`endm'" // year and month to end
  
  //Note: In Stata default for time is 0 at 1960m1: see tsset.  155 assumes start is 1973m1 if not change 155
  local start = tm(`startdate')-155
  local start0=`start'
  local end=tm(`enddate')-155+1 // last forecast date
  
  // Construct series
  foreach i of numlist 1 3 6 9 12 24 36{
    local dateme = `start0'+`i'
    local datemet = `start0'+30
    local endme = `end'+`i'-1
    local endmet = `end'-`i'-1
    qui gen sign`i'=0 in `dateme'/`endme'
    qui gen signy`i'=0 in `dateme'/`endme'
    qui gen signf`i'=0 in `dateme'/`endme'
    qui gen error_a`i'=. in `dateme'/`endme'
    qui gen error_rw`i'=. in `dateme'/`endme'
    qui gen arfor`i'=. in `dateme'/`endme'
    qui gen rwfor`i'=. in `dateme'/`endme'
    qui gen actual`i'=. in `dateme'/`endme'
    qui gen mspet_`p'_lvl_`i'=. in `datemet'/`endmet'
    qui gen mspet_pval_`p'_lvl_`i'=. in `datemet'/`endmet'
    qui gen sr_`p'_lvl_`i'=. in `datemet'/`endmet'
    qui gen sr_pval_`p'_lvl_`i'=. in `datemet'/`endmet'
  }
  // Calculate forecasts
  while  `start0'<`end' {
    qui gen r`var'_rt= `var'/ei_`mm'_`aa'*100
    qui gen f_r`var'_rt = `var'_lastday/ei_`mm'_`aa'*100
    // Real time last ave no-change 
    qui gen r`var'_f = f_r`var'_rt[`start0']
    // Real time no-change 
    qui gen r`var'_rw = r`var'_rt[`start0']
    // Post Forecast Evaluation
    foreach i of numlist 1 3 6 9 12 24 36{
      local sdate = `start0'+`i'
      // Model forecast
      qui replace arfor`i'=r`var'_f in `sdate'/`sdate'
      // Random walk forecast
      qui replace rwfor`i'=r`var'_rw in `sdate'/`sdate'
      // Actual
      qui replace actual`i'=r`var' in `sdate'/`sdate' 
      // Error
      qui replace error_a`i'=r`var'-r`var'_f in `sdate'/`sdate'
      // Random walk
      qui replace error_rw`i'=r`var'-r`var'_rw in `sdate'/`sdate'
      // Calc Success Ratios
      qui replace sign`i'=1 if r`var' - l`i'.r`var' >0 & r`var'_f - l`i'.r`var'_rt >0 in `sdate'/`sdate'
      qui replace sign`i'=1 if r`var' - l`i'.r`var' <0 & r`var'_f - l`i'.r`var'_rt <0 in `sdate'/`sdate'
      qui replace signy`i'=1 if r`var' - l`i'.r`var' >0 in `sdate'/`sdate'
      qui replace signf`i'=1 if r`var'_f - l`i'.r`var'_rt >0 in `sdate'/`sdate'
    } // h
    // Drop Variables
    drop r`var'_f r`var'_rw r`var'_rt f_r`var'_rt
    // Update step by one period
    local start0=`start0'+1
    // Update real time data by one period
    if `mm'<12 { 
      local mm=`mm'+1 
    } 
    else if `mm'==12 { 
      local mm=1 
      local aa=`aa'+1 
    }
  } // date
  foreach i of numlist 1 3 6 9 12 24 36{
    qui gen error_asq`i' = error_a`i'^2
    qui gen error_rwsq`i' = error_rw`i'^2
  } // h
  // AFTER THE MODEL FORECAST EVALUATION CRITERION
  // MSPE Ratios 
  local start0=`start'+30
  while  `start0'<=`end' {
    foreach i of numlist 1 3 6 9 12 24 36{
      local endmet = `end'
      local tdate = `start0'+`i'
	  if `tdate' < `endmet' {
	    qui summarize error_asq`i' in 1/`tdate'
        qui scalar mspet_ar`i' = r(mean)
        qui summarize error_rwsq`i' in 1/`tdate'
        qui scalar mspet_rw`i' = r(mean)
	    qui scalar obs`i' = r(N)
	    qui replace mspet_`p'_lvl_`i' = mspet_ar`i'/mspet_rw`i' in `start0'/`start0'
        local nlags = round(4*(obs`i'/100)^(2/9))
	    //Diebold-Mariano Test 
        capture drop dif
        qui gen dif=error_rwsq`i'-error_asq`i' in 1/`tdate'
        qui newey dif, lag(`nlags')
        matrix M=r(table)
        scalar beta= M[1,1]
	    scalar nwerr= M[2,1]
	    scalar teststat=beta/nwerr
	    scalar pt`i'=1-normal(teststat)
        matrix drop M
	    qui replace mspet_pval_`p'_lvl_`i' = pt`i' in `start0'/`start0'
      } // <end
	} // h
   local start0 = `start0'+1
  } //date
    
  //Success Ratios
  local start0=`start'+30
  while  `start0'<=`end' {
    foreach i of numlist 1 3 6 9 12 24 36{
      local endmet = `end'
      local tdate = `start0'+`i'
      if `tdate' < `endmet' {
  	//Success Ratios Using Pesaran Timmermann 2009 vs AVE
	    qui summarize sign`i' in 1/`tdate'
	    qui scalar phat`i' = r(mean)
	    qui scalar obs`i' = r(N)
	    qui replace sr_`p'_lvl_`i' = phat`i' in `start0'/`start0'
        local nlags = round(4*(obs`i'/100)^(2/9))
	    qui newey signy`i' signf`i' in 1/`tdate', lag(`nlags')
        matrix M=r(table)
	    scalar beta= M[1,1]
	    scalar nwerr= M[2,1]
	    scalar teststat=beta/nwerr
	scalar ptsr`i'=1-normal(teststat)
        matrix drop M
	qui replace sr_pval_`p'_lvl_`i' = ptsr`i' in `start0'/`start0'
      } // if < end
    } // h  
    local start0 = `start0'+1
  } // date
  noisily: display "***********************************************"
  noisily: display "FUTURES, `name', end year = `endy' "
  noisily: display "***********************************************"
  
    // DISPLAY FINAL OBS MSPE AND P-VALUES
  foreach i of numlist 1 3 6 9 12 24 36 {
    capture drop dif difl
    drop error_a`i' error_rw`i' error_asq`i' error_rwsq`i' arfor`i' rwfor`i' actual`i'
    noisily: display "MSPE`i' vsAVE" _s(1) round(mspet_ar`i'/mspet_rw`i',.001) _s(1) round(pt`i',.001) 
	local mspe_and_pvalue`i'  = "" + string(round(mspet_ar`i'/mspet_rw`i',.01))  + " (" + string(round(pt`i',.001)  )  + ")"
  }      
  // DISPLAY FINAL OBS SR AND P-VALUES
  foreach i of numlist 1 3 6 9 12 24 36{
    drop signy`i' signf`i' sign`i'
    noisily: display "SR`i' vsAVE" _s(1) round(phat`i',.001) _s(1) round(ptsr`i',.001) 
	local sr_and_pvalue`i'    = "" + string(round(phat`i',.01))     + " (" + string(round(ptsr`i',.001) )   + ")"
  }  

  local start0=`start'+30
  capture qui outsheet time sr_`p'_lvl_1 sr_pval_`p'_lvl_1  sr_`p'_lvl_3 sr_pval_`p'_lvl_3  sr_`p'_lvl_6 sr_pval_`p'_lvl_6 sr_`p'_lvl_9 sr_pval_`p'_lvl_9 sr_`p'_lvl_12 sr_pval_`p'_lvl_12  sr_`p'_lvl_24 sr_pval_`p'_lvl_24  using "EVOL\SR_`var'_`startdate'_`enddate'.csv" if _n>=`start0' , comma replace
  capture qui outsheet time mspet_`p'_lvl_1 mspet_pval_`p'_lvl_1  mspet_`p'_lvl_3 mspet_pval_`p'_lvl_3 mspet_`p'_lvl_6 mspet_pval_`p'_lvl_6 mspet_`p'_lvl_9 mspet_pval_`p'_lvl_9 mspet_`p'_lvl_12 mspet_pval_`p'_lvl_12   mspet_`p'_lvl_24 mspet_pval_`p'_lvl_24 using "EVOL\mspet_`var'_`p'_`startdate'_`enddate'.csv" if _n>=`start0' , comma replace

  foreach i of numlist 1 3 6 9 12 24 36{
    drop mspet_`p'_lvl_`i' mspet_pval_`p'_lvl_`i' sr_`p'_lvl_`i' sr_pval_`p'_lvl_`i'
  }
    putexcel set "..\..\Results", sheet("table`table'") modify
	putexcel A$pp = "`var', `startdate'-`enddate', `name' "
    putexcel B$pp =  ("`mspe_and_pvalue1'")
    putexcel C$pp =  ("`mspe_and_pvalue3'")      
    putexcel D$pp =  ("`mspe_and_pvalue6'")  
    putexcel E$pp =  ("`mspe_and_pvalue9'")  
	putexcel F$pp =  ("`mspe_and_pvalue12'")  
    putexcel G$pp =  ("`mspe_and_pvalue24'")  
    putexcel H$pp =  ("`mspe_and_pvalue36'")  
    putexcel J$pp =  ("`sr_and_pvalue1'")  
    putexcel K$pp =  ("`sr_and_pvalue3'")  
    putexcel L$pp =  ("`sr_and_pvalue6'")  
    putexcel M$pp =  ("`sr_and_pvalue9'") 
	putexcel N$pp =  ("`sr_and_pvalue12'")  
    putexcel O$pp =  ("`sr_and_pvalue24'")
    putexcel P$pp =  ("`sr_and_pvalue36'")
	global pp=$pp +1
	
// ***************************
// Close and save log file
*} // quietly
log close
translate logfile.smcl "LOGS\log_`startdate'_`enddate'_`var'_cpi`cpi'.log", replace
