// -----------------------------	
// Stephen Snudden Aug 2023
// Replication files for:
// Ellwanger, R. and S. Snudden, 2023. “Futures Prices are Useful Predictors of the Spot Price of Crude Oil” The Energy Journal, vol. 44(4): 65-82.
// -----------------------------	

// Sample 1992.1-2021.1, evaluate 2021.5

//****************
// DATA
//****************
// Compile Futures Data
//*
cd "Data_Historical\CompileFutures"
do "brent_futures.do"  
do "wti_futures.do" 
cd "..\.."
*/

//****************
// Nowcast CPI
//*
cd "Forecasts_M\Nowcasts"
do "Nowcasts.do" 
cd "..\.."
*/

//****************
// FUTURES FORECASTS
//****************

// Imputs: commodity starty startm endy endm nominal=1(real=0) table# Model(EoM=1, AVE=2, EoM_ADJ=3) CPI(nowcast average starting in eiher 73,86,90) realtime(1=yes, 0=no)
// EXAMPLE: 
// do "FUTURES.do" wti 1991 12 2020 12 1 1 1 0
// WTI crude oil, 1991m12-2020m12 (evaluate from 1992m1-2021m1), nominal spot forecasts, table 1, use end of month futures, non-parametric futures forecasts

//****************
// Table 1 - Replication of AK2010 & BK2012
// Note the sample dates are adjusted by t-1 since forecast is for t+1
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 1992.1-2021.1
do "FUTURES.do" wti 1991 12 2020 12 1 1 1 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 1 2 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 1 1 86 1
// 24 Month horizon: 1995.5-2021.1
do "FUTURES.do" wti 1995 5 2020 12 1 1 1 86 1
do "FUTURES.do" wti 1995 5 2020 12 0 1 2 86 1
do "FUTURES.do" wti 1995 5 2020 12 0 1 1 86 1
// 36 Month horizon: 2006.4-2021.1
do "FUTURES.do" wti 2006 3 2020 12 1 1 1 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 1 2 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 1 1 86 1
// Note to get these horizons, change lists in FUTURES.do to "1 3 6 9 12 24 36" to "1 3 6 9 12 24 36 48 60" 
// 48 Month horizon: 2007.4-2021.1
*do "FUTURES.do" wti 2007 3 2020 12 1 1 1 86 1
*do "FUT*URES.do" wti 2007 3 2020 12 0 1 2 86 1
*do "FUTURES.do" wti 2007 3 2020 12 0 1 1 86 1
// 60 Month horizon: 2007.9-2021.1
*do "FUTURES.do" wti 2007 8 2020 12 1 1 1 86 1
*do "FUTURES.do" wti 2007 8 2020 12 0 1 2 86 1
*do "FUTURES.do" wti 2007 8 2020 12 0 1 1 86 1
cd "..\.."
*/


//****************
// Table 2 - Parametric-futures forecasts for WTI
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 1992.1-2021.1
do "FUTURES.do" wti 1991 12 2020 12 0 2 1 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 2 8 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 2 9 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 2 10 86 1
// 36 Month horizon:  2011.4-2021.1   \\ Note, since the 36m futures start in 2006m3, we allow for five years of data for estimation
do "FUTURES.do" wti 2011 3 2020 12 0 2 1 86 1
do "FUTURES.do" wti 2011 3 2020 12 0 2 8 86 1
do "FUTURES.do" wti 2011 3 2020 12 0 2 9 86 1
do "FUTURES.do" wti 2011 3 2020 12 0 2 10 86 1
cd "..\.."
*/

//****************
// Table 3 - Robustness to alternative ways of constructing futures curves for WTI
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 1992.1-2021.1
do "FUTURES.do" wti 1991 12 2020 12 0 3 1 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 3 4 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 3 5 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 3 6 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 3 7 86 1
do "FUTURES.do" wti 1991 12 2020 12 0 3 3 86 1
// 36 Month horizon:  2006.4-2021.1
do "FUTURES.do" wti 2006 3 2020 12 0 3 1 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 3 4 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 3 5 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 3 6 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 3 7 86 1
do "FUTURES.do" wti 2006 3 2020 12 0 3 3 86 1
cd "..\.."
*/

//****************
// Table 4 - Futures-based forecasts for alternative crude oil benchmarks
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 1992.1-2021.1
do "FUTURES.do" wti   1991 12 2020 12 0 4 3 86 1
do "FUTURES.do" brent 1991 12 2020 12 0 4 3 86 1
do "FUTURES.do" rac   1991 12 2020 12 0 4 3 86 1
// 36 Month horizon:  2006.3-2021.1
do "FUTURES.do" wti   2006 3 2020 12 0 4 3 86 1
do "FUTURES.do" brent 2006 3 2020 12 0 4 3 86 1
do "FUTURES.do" rac   2006 3 2020 12 0 4 3 86 1
cd "..\.."
*/

//****************
// Table 5 - Comparison with alternative forecasting approaches
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 1992.1-2021.1
do "FUTURES.do" wti   1991 12 2020 12 0 5 3 86 0
do "FUTURES.do" wti   1991 12 2020 12 0 5 3 73 1
do "FUTURES.do" wti   1991 12 2020 12 0 5 3 86 1
do "FUTURES.do" wti   1991 12 2020 12 0 5 3 90 1
// 36 Month horizon:  2006.4-2021.1
do "FUTURES.do" wti   2006 3 2020 12 0 5 3 86 0
do "FUTURES.do" wti   2006 3 2020 12 0 5 3 73 1
do "FUTURES.do" wti   2006 3 2020 12 0 5 3 86 1
do "FUTURES.do" wti   2006 3 2020 12 0 5 3 90 1
cd "..\.."
*/

//****************
// Table 7 - Comparison with alternative forecasting approaches
//*
global pp=2
cd "Forecasts_M\FUTURES"
// 1-12 Month horizon: 2000.9-2021.1
do "FUTURES.do" wti   2000 8 2020 12 0 7 3 86 1
// 36 Month horizon:  2006.4-2021.1
do "FUTURES.do" wti   2006 3 2020 12 0 7 3 86 1
cd "..\.."
cd "Forecasts_M\NCB"
// 1-12 Month horizon: 2000.9-2021.1
do "NCB.do" wti   2000 8 2020 12 7 86
// 36 Month horizon:  2006.4-2021.1
do "NCB.do" wti   2006 3 2020 12 7 86
cd "..\.."
*/

